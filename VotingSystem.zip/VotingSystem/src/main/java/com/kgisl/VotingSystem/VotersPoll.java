package com.kgisl.VotingSystem;

public class VotersPoll {
    protected String voter_id;
    protected String name;
    protected String email;
    protected String password;
    protected int age;
  
    public VotersPoll(String party_name) {
        this.party_name = party_name;
    }
    protected String gender;
    protected String party_name;
    protected String ward;
    protected int count;
 
    public VotersPoll(String voter_id, String name, String email, String password, int age, String gender,
            String party_name, String ward) {
        this.voter_id = voter_id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.age = age;
        this.gender = gender;
        this.party_name = party_name;
        this.ward = ward;
    }
    public String getVoter_id() {
        return voter_id;
    }
    public void setVoter_id(String voter_id) {
        this.voter_id = voter_id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public String getParty_name() {
        return party_name;
    }
    public void setParty_name(String party_name) {
        this.party_name = party_name;
    }
    public String getWard() {
        return ward;
    }
    public void setWard(String ward) {
        this.ward = ward;
    }
    public int getCount() {
        return count;
    }
    public void setCount(int count) {
        this.count = count;
    }
    @Override
    public String toString() {
        return "VotersPoll [voter_id=" + voter_id + ", name=" + name + ", email=" + email + ", password=" + password
                + ", age=" + age + ", gender=" + gender + ", party_name=" + party_name + ", ward=" + ward +"]";
    }


   

    
}
