package com.kgisl.VotingSystem;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VotersPollDAO {
    
    private PollingDAO pollingDAO;
    private VoterDAO voterDAO;

    static List<VotersPoll> voterspollList = new ArrayList<VotersPoll>();
    static List<Polling> PollingList  = new ArrayList<Polling>();
    static List<Voter> VotersList     = new ArrayList<Voter>();


    public List<VotersPoll> getAllList() throws SQLException{
       
        PollingList=pollingDAO.listAllPollings();
        VotersList= voterDAO.listAllVoters();
        PollingList.forEach(System.out::println);
        VotersList.forEach(System.out::println);
        
        for (Polling polling : PollingList) {
            for (Voter voter : VotersList) {
                if(polling.getVoter_id().equals(voter.getVoter_id())){
                    Polling p = new Polling(polling.getParty_name());
                    VotersPoll votersPoll = new VotersPoll(voter.getVoter_id(), voter.getName(), voter.getEmail(), voter.getPassword(), voter.getAge(), voter.getGender(), p.getParty_name(),voter.getWard());
                    voterspollList.add(votersPoll);

                }
                
            }
            
        }
        voterspollList.forEach(System.out::println);


        return voterspollList;

    }
    
}
