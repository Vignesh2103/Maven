package com.kgisl.VotingSystem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;




@WebServlet(urlPatterns = "/vp")
public class VotersPollServlet extends HttpServlet {
   
    public PollingDAO pollingDAO = new PollingDAO();

    public VoterDAO voterDAO = new VoterDAO();

    @Override
    public void init() throws ServletException {
        String jdbcURL = "jdbc:mysql://localhost:3306/votingsystem";
        String jdbcUsername = "root";
        String jdbcPassword = "";
        
        pollingDAO = PollingDAO.getInstance(jdbcURL, jdbcUsername, jdbcPassword);
        voterDAO = VoterDAO.getInstance(jdbcURL, jdbcUsername, jdbcPassword);
    }

    static List<VotersPoll> voterspollList = new ArrayList<VotersPoll>();
    static List<Polling> PollingList  = new ArrayList<Polling>();
    static List<Voter> VotersList     = new ArrayList<Voter>();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            PollingList=pollingDAO.listAllPollings();
            VotersList= voterDAO.listAllVoters();
        // for (Polling polling : PollingList) {
        //     if(polling == null){
        //         System.out.println("null");
        //     }
        //     else{
        //         System.out.println(polling);
        //     }
        // }
        // for (Voter voter : VotersList) {
        //     if(voter == null){
        //         System.out.println("null");
        //     }
        //     else{
        //         System.out.println(voter);
        //     }
            
        // }
        
        for (Polling polling : PollingList) {
            for (Voter voter : VotersList) {
                if(polling.getVoter_id().equals(voter.getVoter_id())){
                    Polling p = new Polling(polling.getParty_name());
                    VotersPoll votersPoll = new VotersPoll(voter.getVoter_id(), voter.getName(), voter.getEmail(), voter.getPassword(), voter.getAge(), voter.getGender(), p.getParty_name(),voter.getWard());
                    voterspollList.add(votersPoll);

                }
                
            }
            
        }
        //Party Based  gender count
        Map<String, Map<String, Long>> genderCount = voterspollList.stream().collect(Collectors.groupingBy(VotersPoll::getParty_name, Collectors.groupingBy(VotersPoll::getGender, Collectors.counting())));

        genderCount.entrySet().stream().forEach(i ->System.out.println(i.getKey() + " "+i.getValue()));

        //non voterts
        List<Voter> nonVoters=  VotersList.stream().filter(voter -> PollingList.stream().noneMatch(polling -> polling.getVoter_id().equals(voter.getVoter_id()))).collect(Collectors.toList());
        
        nonVoters.forEach(System.out::println);


        //party count
        Map<String, Long> partyCount = voterspollList.stream().collect(Collectors.groupingBy(VotersPoll::getParty_name, Collectors.counting()));

        partyCount.entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue().reversed()).forEach(i -> System.out.println(i.getKey()+" "+i.getValue()));

        Map<String,Object> result= new HashMap<String, Object>() ;

        result.put("genderCount",genderCount);
        result.put("nonVoters",nonVoters);
        result.put("partyCount", partyCount);


        String json = new Gson().toJson(result);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(json);

        System.out.println(json);

    


   

    

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
    
    }
    


