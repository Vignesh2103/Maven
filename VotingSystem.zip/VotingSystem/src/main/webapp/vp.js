const uri = "http://localhost:9090/vp";

function getAllResults() {
    console.log("Display Item");
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            console.log(JSON.parse(xhttp.responseText));
            var response = JSON.parse(xhttp.responseText);
            displaygenderCount(response.genderCount);
            // displaynonVoters(response.nonVoters);
            // displaypartyCount(response.partyCount);
        }
    };
    xhttp.open("GET", uri, true);
    xhttp.send();
}

function displaygenderCount(data) {
    const tableBody = document.getElementById('table-body');
    
    for (const partyName in data) {
        const row = document.createElement('tr');
        const nameCell = document.createElement('td');
        const femaleCell = document.createElement('td');
        const maleCell = document.createElement('td');
  
        nameCell.textContent = partyName;
        femaleCell.textContent = data[partyName].Female || 0;
        maleCell.textContent = data[partyName].Male || 0;
  
        row.appendChild(nameCell);
        row.appendChild(femaleCell);
        row.appendChild(maleCell);
  
        tableBody.appendChild(row);
    }
}
